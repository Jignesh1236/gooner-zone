import React, { useEffect, useState, useCallback, useRef, memo } from "react";
import {
  StyleSheet,
  View,
  Pressable,
  Dimensions,
  ScrollView,
  Platform,
  ActivityIndicator,
  NativeSyntheticEvent,
  NativeScrollEvent,
  LayoutChangeEvent,
} from "react-native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RouteProp } from "@react-navigation/native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import { StatusBar } from "expo-status-bar";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { LoadingIndicator } from "@/components/LoadingIndicator";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius, Colors } from "@/constants/theme";
import { mangadexApi } from "@/services/mangadex";
import { storage } from "@/services/storage";
import { BrowseStackParamList } from "@/navigation/BrowseStackNavigator";

type ChapterReaderScreenProps = {
  navigation: NativeStackNavigationProp<BrowseStackParamList, "ChapterReader">;
  route: RouteProp<BrowseStackParamList, "ChapterReader">;
};

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get("window");

interface PageItemProps {
  uri: string;
  index: number;
  onTap: () => void;
  onLayout: (index: number, height: number) => void;
}

const PageItem = memo(({ uri, index, onTap, onLayout }: PageItemProps) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [aspectRatio, setAspectRatio] = useState(0.7);

  const handleRetry = useCallback(() => {
    setError(false);
    setLoading(true);
    setRetryKey((k) => k + 1);
  }, []);

  const handleLayout = useCallback(
    (e: LayoutChangeEvent) => {
      onLayout(index, e.nativeEvent.layout.height);
    },
    [index, onLayout]
  );

  return (
    <Pressable onPress={onTap} style={styles.pageWrapper} onLayout={handleLayout}>
      <View style={[styles.imageContainer, { aspectRatio }]}>
        {loading && (
          <View style={styles.loadingOverlay}>
            <ActivityIndicator size="small" color={Colors.dark.accent} />
          </View>
        )}

        {error && (
          <View style={styles.errorOverlay}>
            <Feather name="image" size={32} color="#666" />
            <Pressable
              onPress={handleRetry}
              style={({ pressed }) => [
                styles.retryBtn,
                { opacity: pressed ? 0.7 : 1 },
              ]}
            >
              <Feather name="refresh-cw" size={14} color="#FFF" />
              <ThemedText type="caption" lightColor="#FFF" darkColor="#FFF">
                Retry
              </ThemedText>
            </Pressable>
          </View>
        )}

        <Image
          key={`${uri}-${retryKey}`}
          source={{ uri }}
          style={styles.pageImage}
          contentFit="contain"
          cachePolicy="memory-disk"
          recyclingKey={uri}
          priority={index < 5 ? "high" : "normal"}
          onLoadStart={() => {
            setLoading(true);
            setError(false);
          }}
          onLoad={(e) => {
            setLoading(false);
            const { width, height } = e.source;
            if (width && height) {
              setAspectRatio(width / height);
            }
          }}
          onError={() => {
            setLoading(false);
            setError(true);
          }}
        />
      </View>
    </Pressable>
  );
});

export default function ChapterReaderScreen({
  navigation,
  route,
}: ChapterReaderScreenProps) {
  const { chapterId, mangaId, mangaTitle, chapterNumber } = route.params;
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();

  const scrollRef = useRef<ScrollView>(null);
  const [pages, setPages] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [showControls, setShowControls] = useState(false);
  const [initialScrollDone, setInitialScrollDone] = useState(false);

  const hideTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const savedStartPageRef = useRef(0);
  const pageOffsetsRef = useRef<number[]>([]);
  const pageHeightsRef = useRef<number[]>([]);
  const scrollYRef = useRef(0);

  useEffect(() => {
    loadChapter();
    return () => {
      if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
    };
  }, [chapterId]);

  const loadChapter = async () => {
    try {
      setLoading(true);
      setInitialScrollDone(false);
      pageOffsetsRef.current = [];
      pageHeightsRef.current = [];

      const savedProgress = await storage.getReadingProgress(mangaId);
      if (savedProgress && savedProgress.chapterId === chapterId) {
        savedStartPageRef.current = savedProgress.page || 0;
      } else {
        savedStartPageRef.current = 0;
      }

      const data = await mangadexApi.getChapterPages(chapterId);
      setPages(data.pages);
      setCurrentPage(savedStartPageRef.current);

      const defaultHeight = SCREEN_WIDTH * 1.4;
      pageHeightsRef.current = data.pages.map(() => defaultHeight);
      let offset = 0;
      pageOffsetsRef.current = data.pages.map((_, i) => {
        const currentOffset = offset;
        offset += pageHeightsRef.current[i];
        return currentOffset;
      });

      await storage.markChapterAsRead(mangaId, chapterId);
    } catch (err) {
      console.error("Failed to load chapter:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (pages.length > 0 && !initialScrollDone && savedStartPageRef.current > 0) {
      const targetPage = Math.min(savedStartPageRef.current, pages.length - 1);
      setTimeout(() => {
        const offset = pageOffsetsRef.current[targetPage] || 0;
        scrollRef.current?.scrollTo({ y: offset, animated: false });
        setInitialScrollDone(true);
      }, 300);
    } else if (pages.length > 0 && !initialScrollDone) {
      setInitialScrollDone(true);
    }
  }, [pages, initialScrollDone]);

  const saveProgress = useCallback(
    async (page: number) => {
      if (pages.length === 0) return;
      await storage.saveReadingProgress({
        mangaId,
        chapterId,
        chapterNumber,
        page,
        totalPages: pages.length,
        updatedAt: Date.now(),
      });
    },
    [mangaId, chapterId, chapterNumber, pages.length]
  );

  useEffect(() => {
    if (pages.length > 0 && initialScrollDone) {
      saveProgress(currentPage);
    }
  }, [currentPage, pages.length, saveProgress, initialScrollDone]);

  const handlePageLayout = useCallback((index: number, height: number) => {
    if (pageHeightsRef.current[index] !== height) {
      pageHeightsRef.current[index] = height;
      let offset = 0;
      for (let i = 0; i < pageHeightsRef.current.length; i++) {
        pageOffsetsRef.current[i] = offset;
        offset += pageHeightsRef.current[i];
      }
    }
  }, []);

  const handleScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const offsetY = event.nativeEvent.contentOffset.y;
      scrollYRef.current = offsetY;

      let page = 0;
      for (let i = 0; i < pageOffsetsRef.current.length; i++) {
        const pageTop = pageOffsetsRef.current[i];
        const pageHeight = pageHeightsRef.current[i] || SCREEN_HEIGHT;
        const pageMid = pageTop + pageHeight / 2;
        if (offsetY + SCREEN_HEIGHT / 2 >= pageMid) {
          page = i;
        }
      }

      if (page !== currentPage) {
        setCurrentPage(page);
      }
    },
    [currentPage]
  );

  const toggleControls = useCallback(() => {
    if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);

    const next = !showControls;
    setShowControls(next);

    if (next) {
      hideTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 4000);
    }
  }, [showControls]);

  const scrollToPage = useCallback(
    (pageIndex: number) => {
      if (pageIndex < 0 || pageIndex >= pages.length) return;

      const offset = pageOffsetsRef.current[pageIndex] || 0;
      scrollRef.current?.scrollTo({ y: offset, animated: true });
      setCurrentPage(pageIndex);

      if (Platform.OS !== "web") {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
    },
    [pages.length]
  );

  const goBack = useCallback(() => navigation.goBack(), [navigation]);

  useEffect(() => {
    if (Platform.OS === "web") {
      const handleKey = (e: KeyboardEvent) => {
        if (e.key === "ArrowDown" || e.key === " " || e.key === "ArrowRight") {
          e.preventDefault();
          scrollToPage(currentPage + 1);
        } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
          e.preventDefault();
          scrollToPage(currentPage - 1);
        } else if (e.key === "Escape") {
          goBack();
        }
      };
      window.addEventListener("keydown", handleKey);
      return () => window.removeEventListener("keydown", handleKey);
    }
  }, [currentPage, scrollToPage, goBack]);

  useEffect(() => {
    if (pages.length > 0 && currentPage >= 0) {
      const toPrefetch: string[] = [];
      for (let i = 1; i <= 3; i++) {
        if (currentPage + i < pages.length) toPrefetch.push(pages[currentPage + i]);
        if (currentPage - i >= 0) toPrefetch.push(pages[currentPage - i]);
      }
      toPrefetch.forEach((url) => Image.prefetch(url));
    }
  }, [currentPage, pages]);

  if (loading) {
    return (
      <View style={[styles.container, styles.centered]}>
        <StatusBar style="light" />
        <LoadingIndicator fullScreen />
      </View>
    );
  }

  if (pages.length === 0) {
    return (
      <View style={[styles.container, styles.centered]}>
        <StatusBar style="light" />
        <Feather name="alert-circle" size={48} color="#666" />
        <ThemedText
          type="body"
          style={styles.noPageText}
          lightColor="#999"
          darkColor="#999"
        >
          No pages available
        </ThemedText>
        <Pressable
          onPress={goBack}
          style={({ pressed }) => [
            styles.goBackBtn,
            { backgroundColor: theme.primary, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <ThemedText type="body" lightColor="#FFF" darkColor="#FFF">
            Go Back
          </ThemedText>
        </Pressable>
      </View>
    );
  }

  const progress = ((currentPage + 1) / pages.length) * 100;

  return (
    <View style={styles.container}>
      <StatusBar style="light" hidden={!showControls} />

      <ScrollView
        ref={scrollRef}
        showsVerticalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        contentContainerStyle={styles.scrollContent}
      >
        {pages.map((uri, idx) => (
          <PageItem
            key={idx}
            uri={uri}
            index={idx}
            onTap={toggleControls}
            onLayout={handlePageLayout}
          />
        ))}
      </ScrollView>

      {!showControls && (
        <View
          style={[
            styles.pageIndicator,
            { bottom: Math.max(insets.bottom, 16) + 8 },
          ]}
        >
          <ThemedText
            type="caption"
            lightColor="#FFF"
            darkColor="#FFF"
            style={styles.pageIndicatorText}
          >
            {currentPage + 1} / {pages.length}
          </ThemedText>
        </View>
      )}

      {showControls && (
        <>
          <View style={[styles.header, { paddingTop: insets.top }]}>
            <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
            <Pressable
              onPress={goBack}
              style={({ pressed }) => [
                styles.headerBtn,
                { opacity: pressed ? 0.6 : 1 },
              ]}
            >
              <Feather name="x" size={24} color="#FFF" />
            </Pressable>
            <View style={styles.headerCenter}>
              <ThemedText
                type="small"
                numberOfLines={1}
                lightColor="#FFF"
                darkColor="#FFF"
                style={styles.titleText}
              >
                {mangaTitle}
              </ThemedText>
              <ThemedText
                type="caption"
                lightColor="rgba(255,255,255,0.7)"
                darkColor="rgba(255,255,255,0.7)"
              >
                Chapter {chapterNumber}
              </ThemedText>
            </View>
            <View style={styles.headerBtn} />
          </View>

          <View
            style={[
              styles.footer,
              { paddingBottom: Math.max(insets.bottom, 8) },
            ]}
          >
            <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={styles.footerInner}>
              <View style={styles.navRow}>
                <Pressable
                  onPress={() => scrollToPage(currentPage - 1)}
                  disabled={currentPage === 0}
                  style={({ pressed }) => [
                    styles.navBtn,
                    { opacity: currentPage === 0 ? 0.3 : pressed ? 0.6 : 1 },
                  ]}
                >
                  <Feather name="chevron-up" size={24} color="#FFF" />
                </Pressable>

                <View style={styles.pageInfo}>
                  <ThemedText
                    type="h4"
                    lightColor="#FFF"
                    darkColor="#FFF"
                    style={styles.pageNum}
                  >
                    {currentPage + 1}
                  </ThemedText>
                  <ThemedText
                    type="caption"
                    lightColor="rgba(255,255,255,0.6)"
                    darkColor="rgba(255,255,255,0.6)"
                  >
                    of {pages.length}
                  </ThemedText>
                </View>

                <Pressable
                  onPress={() => scrollToPage(currentPage + 1)}
                  disabled={currentPage === pages.length - 1}
                  style={({ pressed }) => [
                    styles.navBtn,
                    {
                      opacity:
                        currentPage === pages.length - 1 ? 0.3 : pressed ? 0.6 : 1,
                    },
                  ]}
                >
                  <Feather name="chevron-down" size={24} color="#FFF" />
                </Pressable>
              </View>

              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${progress}%`, backgroundColor: Colors.dark.accent },
                  ]}
                />
              </View>
            </View>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.readerBackground,
  },
  centered: {
    justifyContent: "center",
    alignItems: "center",
    gap: Spacing.lg,
  },
  noPageText: {
    textAlign: "center",
  },
  goBackBtn: {
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.md,
    marginTop: Spacing.md,
  },
  scrollContent: {
    flexGrow: 1,
  },
  pageWrapper: {
    width: SCREEN_WIDTH,
    backgroundColor: Colors.dark.readerBackground,
  },
  imageContainer: {
    width: SCREEN_WIDTH,
    backgroundColor: Colors.dark.readerBackground,
  },
  pageImage: {
    width: "100%",
    height: "100%",
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.dark.readerBackground,
    zIndex: 1,
  },
  errorOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.dark.readerBackground,
    gap: Spacing.sm,
    zIndex: 2,
  },
  retryBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    backgroundColor: Colors.dark.accent,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
  },
  pageIndicator: {
    position: "absolute",
    alignSelf: "center",
    backgroundColor: "rgba(0,0,0,0.6)",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  pageIndicatorText: {
    fontWeight: "600",
  },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.sm,
    paddingBottom: Spacing.sm,
    overflow: "hidden",
  },
  headerBtn: {
    width: 44,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
  },
  headerCenter: {
    flex: 1,
    alignItems: "center",
  },
  titleText: {
    fontWeight: "600",
    textAlign: "center",
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.md,
    paddingTop: Spacing.md,
    overflow: "hidden",
  },
  footerInner: {
    alignItems: "center",
    gap: Spacing.md,
  },
  navRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xl,
  },
  navBtn: {
    width: 44,
    height: 44,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: BorderRadius.full,
  },
  pageInfo: {
    alignItems: "center",
    minWidth: 60,
  },
  pageNum: {
    fontWeight: "700",
  },
  progressBar: {
    width: "100%",
    height: 3,
    backgroundColor: "rgba(255,255,255,0.2)",
    borderRadius: 2,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
});
